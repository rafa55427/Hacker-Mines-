# hack-do-mines
Um hack para o jogo de cassino mines, gratuito.
## [Testar Hack](http://144.22.145.131:8181/)
###
![WhatsApp Image 2023-05-07 at 15 38 08](https://github.com/proxlu/hack-do-mines/assets/105125779/54de5ce9-05c7-48f0-b07d-be9c2fcd37cd)
###
OBS: Os arquivos devem ser colocados na raíz do seu site (http://localhost/) para funcionar corretamente.
